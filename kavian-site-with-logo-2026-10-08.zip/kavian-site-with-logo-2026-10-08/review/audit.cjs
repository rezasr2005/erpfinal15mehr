const { chromium } = require('playwright');
const fs = require('fs');
const assert = require('node:assert/strict');
const base = process.env.REVIEW_BASE || 'http://127.0.0.1:3000';
const output = process.env.REVIEW_OUTPUT || '/workspace/site-review';
fs.mkdirSync(output, {recursive:true});
(async () => {
  const browser = await chromium.launch({executablePath:'/usr/bin/chromium', args:['--no-sandbox']});
  const page = await browser.newPage();
  const errors = [], results = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('response', r => {if(r.status()>=400) errors.push(`${r.status()} ${r.url()}`);});
  page.on('console', m => { if(m.type()==='error') errors.push(m.text()); });
  const paths = ['inquiry','','products','scrap','sell-scrap','contact','about','khavarshahr','market','erp','inventory','prices','clients'];
  for(const width of [320,375,768,1100,1440]) {
    await page.setViewportSize({width,height:900});
    for(const locale of ['fa','en']) {
      for(const path of paths) {
        const route=`/${locale}${path?'/'+path:''}`;
        const response=await page.goto(base+route,{waitUntil:'networkidle'});
        const data=await page.evaluate(() => ({
          lang:document.documentElement.lang,dir:document.documentElement.dir,
          scrollWidth:document.documentElement.scrollWidth,width:innerWidth,
          title:document.title,h1:document.querySelectorAll('h1').length,
          robots:document.querySelector('meta[name="robots"]')?.content,
          overflow:[...document.querySelectorAll('body *')].filter(e=> {
            const r=e.getBoundingClientRect();return r.width && (r.right>innerWidth+1 || r.left < -1) && getComputedStyle(e).position!=='fixed';
          }).slice(0,10).map(e=>({tag:e.tagName,cls:e.className,text:e.textContent.slice(0,70)})),
        }));
        results.push({route,width,status:response.status(),...data});
        if(width===320 || width===1440 || path==='inquiry') await page.screenshot({path:`${output}/${locale}-${path||'home'}-${width}.png`,fullPage:true});
      }
      console.log(`Completed ${locale} at ${width}px`);
    }
  }
  fs.writeFileSync(`${output}/layout-results.json`,JSON.stringify({results,errors},null,2));
  console.log('Layout failures:',JSON.stringify(results.filter(r=>r.status!==200||r.scrollWidth>r.width||r.overflow.length||r.h1!==1)));
  console.log('Console/page errors:',errors);
  await browser.close();
  assert.equal(results.filter(r=>r.status!==200||r.scrollWidth>r.width||r.overflow.length||r.h1!==1||r.lang!==r.route.split('/')[1]||r.dir!==(r.lang==='fa'?'rtl':'ltr')).length,0);
  assert.equal(errors.length,0);
})().catch(e=>{console.error(e);process.exit(1)});
