const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('fs');
const base=process.env.REVIEW_BASE || 'http://127.0.0.1:3002';
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 const page=await browser.newPage();const routes=new Map();
 for(const locale of ['fa','en'])for(const path of ['', 'inquiry','products','scrap','sell-scrap','contact','about','khavarshahr','market','erp','inventory','prices','clients']){
  const route=`/${locale}${path?'/'+path:''}`;
  await page.goto(base+route,{waitUntil:'networkidle'});
  const data=await page.evaluate(()=>({
   ids:[...document.querySelectorAll('[id]')].map(e=>e.id),
   links:[...document.querySelectorAll('a[href]')].map(e=>e.href),
   robots:document.querySelector('meta[name="robots"]')?.content || '',
   title:document.title,description:document.querySelector('meta[name="description"]')?.content,
   icon:document.querySelector('link[rel="icon"]')?.href,
  }));
  assert(data.title && data.description,route);
  assert.equal(data.robots.includes('noindex'),['inquiry','inventory','prices','clients'].includes(path),route);
  assert(data.icon.endsWith('/kavian-mark.svg'),route);
  routes.set(route,data);
 }
 const issues=[];
 for(const [route,data] of routes)for(const link of data.links){
  const u=new URL(link);if(u.origin!==base)continue;
  const dest=routes.get(u.pathname);if(!dest){issues.push(`${route}: missing route ${u.pathname}`);continue;}
  if(u.hash&&!dest.ids.includes(decodeURIComponent(u.hash.slice(1))))issues.push(`${route}: missing anchor ${u.pathname}${u.hash}`);
 }
 const sitemap=await (await fetch(base+'/sitemap.xml')).text();
 const urls=[...sitemap.matchAll(/<loc>(.*?)<\/loc>/g)].map(m=>new URL(m[1]).pathname);
 assert.equal(urls.length,18);assert.equal(new Set(urls).size,18);
 for(const route of routes.keys())assert.equal(urls.includes(route),!routes.get(route).robots.includes('noindex'),route);
 const icon=await fetch(base+'/kavian-mark.svg');assert.equal(icon.status,200);
 fs.writeFileSync('/workspace/site-review/after/metadata-results.json',JSON.stringify({routes:Object.fromEntries(routes),sitemapRoutes:urls,issues},null,2));
 assert.deepEqual(issues,[]);
 console.log('26 page titles/descriptions, expected noindex, 18 sitemap entries, icon response and all internal routes/anchors passed');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
