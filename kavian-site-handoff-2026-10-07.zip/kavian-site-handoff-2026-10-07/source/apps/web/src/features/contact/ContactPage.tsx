import Link from "next/link";
import type { SupportedLocale } from "@kavian/config";
import { contactContent } from "./content";
import { ContactChannel } from "./ContactChannel";
import "./contact.css";

export function ContactPage({ locale }: { locale: SupportedLocale }) {
  const text = contactContent[locale];
  return <main className="contact-page">
    <section className="contact-hero" aria-labelledby="contact-title"><div className="container"><nav className="contact-breadcrumb" aria-label={locale === "fa" ? "مسیر صفحه" : "Breadcrumb"}><Link href={`/${locale}`}>{text.home}</Link><span aria-hidden="true">/</span><span aria-current="page">{text.title}</span></nav><p className="contact-eyebrow">{text.eyebrow}</p><h1 id="contact-title">{text.title}</h1><p className="contact-intro">{text.intro}</p></div></section>
    <section className="container contact-section" aria-labelledby="contact-channels-title"><h2 id="contact-channels-title">{text.detailsTitle}</h2><div className="contact-channel-grid">{text.channels.map((channel) => <ContactChannel key={channel.title} title={channel.title} text={channel.text} pending={text.pending} />)}</div><div className="contact-support"><div><h3>{text.hours}</h3><p>{text.pending}</p></div><div><h3>{text.social}</h3><p>{text.socialNote}</p><div className="contact-social" dir="ltr"><span aria-disabled="true">LinkedIn</span><span aria-disabled="true">Instagram</span></div></div></div></section>
    <section className="contact-guides" aria-labelledby="contact-guides-title"><div className="container"><h2 id="contact-guides-title">{text.guideTitle}</h2><p className="contact-guide-intro">{text.guideText}</p><div className="contact-guide-grid">{text.guides.map((guide) => <article className="contact-guide-card" key={guide.path}><h3>{guide.title}</h3><p>{guide.text}</p><Link href={`/${locale}${guide.path}`}>{guide.link}<span aria-hidden="true">↗</span></Link></article>)}</div></div></section>
  </main>;
}
