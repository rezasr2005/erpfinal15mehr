export function ContactChannel({ title, text, pending }: { title: string; text: string; pending: string }) {
  return <article className="contact-channel"><h3>{title}</h3><p className="contact-placeholder">{pending}</p><p>{text}</p></article>;
}
