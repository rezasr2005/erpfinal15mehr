export const contactContent = {
  fa: {
    brand: "هلدینگ فولاد کاویان سپنتا", home: "خانه", title: "تماس با ما",
    description: "صفحه‌ی ارتباط با هلدینگ فولاد کاویان سپنتا و راهنمای آماده‌سازی اطلاعات درخواست محصولات و ضایعات.",
    eyebrow: "ارتباط با هلدینگ", intro: "برای گفت‌وگو درباره‌ی محصولات فولادی و ضایعات صنعتی، اطلاعات نیاز خود را آماده کنید. راه‌های ارتباطی رسمی مجموعه پس از تأیید در این صفحه درج می‌شوند.",
    detailsTitle: "راه‌های ارتباطی", pending: "به‌زودی اعلام می‌شود",
    channels: [ { title: "تلفن", text: "شماره‌ی تماس رسمی مجموعه" }, { title: "ایمیل", text: "نشانی ایمیل رسمی مجموعه" }, { title: "آدرس", text: "نشانی مراجعه و اطلاعات دسترسی" } ],
    hours: "ساعات پاسخ‌گویی", social: "شبکه‌های اجتماعی", socialNote: "لینک حساب‌های رسمی پس از تأیید اضافه می‌شود.",
    guideTitle: "پیش از تماس، موضوع خود را مشخص کنید", guideText: "برای آماده‌سازی اطلاعات درخواست، از راهنماهای زیر استفاده کنید.",
    guides: [
      { title: "درخواست محصولات فولادی", text: "نوع محصول، ابعاد، گرید، مقدار و شرایط تحویل مورد نظر را آماده کنید.", link: "راهنمای محصولات", path: "/products" },
      { title: "معرفی ضایعات قابل عرضه", text: "جنس، وزن تقریبی، تصاویر و محل نگهداری محموله را مشخص کنید.", link: "راهنمای خرید ضایعات", path: "/sell-scrap" },
    ],
  },
  en: {
    brand: "Kavian Sepanta Steel Holding", home: "Home", title: "Contact us",
    description: "Contact information for Kavian Sepanta Steel Holding and guidance on preparing steel product and scrap inquiries.",
    eyebrow: "Connect with the holding", intro: "Prepare your requirements to discuss steel products or industrial scrap. Official contact channels will be published here once confirmed.",
    detailsTitle: "Contact channels", pending: "To be announced",
    channels: [ { title: "Phone", text: "The holding’s official phone number" }, { title: "Email", text: "The holding’s official email address" }, { title: "Address", text: "Visitor address and access information" } ],
    hours: "Contact hours", social: "Social media", socialNote: "Official account links will be added once confirmed.",
    guideTitle: "Define your inquiry before contacting us", guideText: "Use these guides to prepare the details of your request.",
    guides: [
      { title: "Steel product inquiries", text: "Prepare the product type, dimensions, grade, quantity and delivery requirements.", link: "Product guide", path: "/products" },
      { title: "Offering scrap for sale", text: "Identify the material, approximate weight, photographs and load location.", link: "Sell scrap guide", path: "/sell-scrap" },
    ],
  },
};
