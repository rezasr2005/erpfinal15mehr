export const aboutContent = {
  fa: {
    brand: "هلدینگ فولاد کاویان سپنتا", home: "خانه", title: "درباره ما",
    description: "معرفی هلدینگ فولاد کاویان سپنتا و حوزه‌های فعالیت در تأمین و تجارت فولاد، آهن‌آلات و ضایعات صنعتی.",
    eyebrow: "آشنایی با هلدینگ", heroTitle: "در امتداد زنجیره‌ی تأمین فولاد",
    intro: "هلدینگ فولاد کاویان سپنتا در حوزه‌ی تأمین و تجارت فولاد، آهن‌آلات و ضایعات صنعتی فعالیت می‌کند.",
    identityLabel: "معرفی مجموعه", identityTitle: "فولاد، آهن‌آلات و ضایعات صنعتی",
    identityText: "این وب‌سایت مسیر آشنایی با حوزه‌های فعالیت هلدینگ و آماده‌سازی درخواست‌های مرتبط با محصولات فولادی و ضایعات است. برای شناخت گروه‌های عمومی محصولات، معرفی محموله‌ی ضایعات یا دسترسی به اطلاعات تماس، از صفحات مرتبط استفاده کنید.",
    focusLabel: "حوزه‌های فعالیت", focusTitle: "با مسیرهای اصلی فعالیت آشنا شوید",
    areas: [
      { title: "محصولات فولادی", text: "معرفی گروه‌های عمومی محصولات فولادی و اطلاعات لازم برای بیان نیاز محصول.", link: "شناخت محصولات", path: "/products" },
      { title: "ضایعات فلزی و صنعتی", text: "راهنمای شناخت جنس، منشأ و وضعیت ضایعات برای معرفی دقیق‌تر اقلام.", link: "شناخت ضایعات", path: "/scrap" },
      { title: "معرفی ضایعات قابل عرضه", text: "راهنمای آماده‌سازی مشخصات محموله، مقدار، تصاویر و شرایط دسترسی.", link: "راهنمای خرید ضایعات", path: "/sell-scrap" },
    ],
    ctaTitle: "برای آشنایی بیشتر یا طرح نیاز خود", ctaText: "از صفحه‌ی تماس، راه‌های ارتباطی مجموعه و راهنماهای آماده‌سازی درخواست را دنبال کنید.", contact: "تماس با ما",
  },
  en: {
    brand: "Kavian Sepanta Steel Holding", home: "Home", title: "About us",
    description: "An introduction to Kavian Sepanta Steel Holding and its focus on the supply and trading of steel, metal products and industrial scrap.",
    eyebrow: "Meet the holding", heroTitle: "Across the steel supply chain",
    intro: "Kavian Sepanta Steel Holding operates in the supply and trading of steel, metal products and industrial scrap.",
    identityLabel: "The holding", identityTitle: "Steel, metal products & industrial scrap",
    identityText: "This website introduces the holding’s areas of activity and helps prepare inquiries about steel products and scrap. Explore the related pages to learn about general product groups, describe a scrap load or find contact information.",
    focusLabel: "Our focus", focusTitle: "Explore our principal areas of activity",
    areas: [
      { title: "Steel products", text: "An introduction to general steel product groups and the details needed to describe your requirements.", link: "Explore products", path: "/products" },
      { title: "Metal & industrial scrap", text: "Guidance on identifying material, origin and condition to describe scrap more clearly.", link: "Explore scrap", path: "/scrap" },
      { title: "Offering scrap for sale", text: "A guide to preparing load specifications, quantity, photographs and access details.", link: "Sell scrap guide", path: "/sell-scrap" },
    ],
    ctaTitle: "Learn more or introduce your requirements", ctaText: "Visit the contact page for the holding’s contact channels and guides to preparing your inquiry.", contact: "Contact us",
  },
};
