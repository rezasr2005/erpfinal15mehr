export const warehouseContent = {
  fa: {
    brand: "هلدینگ فولاد کاویان سپنتا", home: "خانه", title: "انبار خاورشهر",
    description: "صفحه‌ی معرفی انبار خاورشهر؛ اطلاعات دسترسی، مشخصات و تصاویر پس از تأیید مجموعه منتشر می‌شوند.",
    eyebrow: "معرفی انبار", intro: "اطلاعات معرفی، دسترسی و هماهنگی انبار خاورشهر در این صفحه قرار می‌گیرد. جزئیات زیر پس از تأیید مجموعه تکمیل می‌شوند.",
    infoTitle: "اطلاعات انبار", pending: "به‌زودی اعلام می‌شود",
    details: ["آدرس و مسیر دسترسی", "ساعات مراجعه", "راه ارتباطی و هماهنگی", "ظرفیت و مشخصات انبار", "خدمات و امکانات"],
    locationTitle: "موقعیت و دسترسی", locationText: "آدرس دقیق و موقعیت روی نقشه پس از تأیید منتشر می‌شود.",
    imagesTitle: "تصاویر انبار", imagesText: "تصاویر واقعی و تأییدشده‌ی انبار به این بخش اضافه خواهند شد.", imagePlaceholder: "تصویر انبار — در انتظار تکمیل",
    visitTitle: "پیش از مراجعه هماهنگ کنید", visitText: "برای اطلاع از شرایط مراجعه و دسترسی، راه‌های ارتباطی مجموعه را در صفحه‌ی تماس دنبال کنید. اطلاعات تماس نیز فعلاً در انتظار تکمیل است.", contact: "تماس با ما", products: "معرفی محصولات",
  },
  en: {
    brand: "Kavian Sepanta Steel Holding", home: "Home", title: "Khavarshahr warehouse",
    description: "An introduction to the Khavarshahr warehouse. Access information, specifications and photographs will be published after confirmation by the holding.",
    eyebrow: "Warehouse overview", intro: "This page will provide introduction, access and coordination information for the Khavarshahr warehouse. The details below will be completed once confirmed by the holding.",
    infoTitle: "Warehouse information", pending: "To be announced",
    details: ["Address & directions", "Visiting hours", "Contact & coordination", "Capacity & specifications", "Services & facilities"],
    locationTitle: "Location & access", locationText: "The exact address and map location will be published once confirmed.",
    imagesTitle: "Warehouse photographs", imagesText: "Actual, approved photographs of the warehouse will be added here.", imagePlaceholder: "Warehouse photograph — pending",
    visitTitle: "Coordinate before visiting", visitText: "Follow the holding’s contact channels on the contact page for visiting and access information. Contact details are also awaiting completion.", contact: "Contact us", products: "Explore products",
  },
};
