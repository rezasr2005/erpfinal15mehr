import Link from "next/link";
import type { SupportedLocale } from "@kavian/config";
import { messages, navigation } from "../navigation/messages";

export function Footer({ locale }: { locale: SupportedLocale }) {
  const text = messages[locale];
  return (
    <footer className="public-footer">
      <div className="container footer-grid">
        <div className="footer-intro"><span className="footer-eyebrow" lang="en" dir="ltr">KAVIAN SEPANTA</span><h2>{text.brand}</h2><p>{text.intro}</p></div>
        <nav aria-label={text.links}><h2>{text.links}</h2><ul>{navigation.filter(({ key }) => ["home", "products", "scrap", "warehouse", "clients", "about", "contact"].includes(key)).map(({ key, path }) => <li key={key}><Link href={`/${locale}${path}`}>{text[key]}</Link></li>)}</ul></nav>
        <nav aria-label={text.services}><h2>{text.services}</h2><ul>{navigation.filter(({ key }) => ["market", "erp", "inventory", "prices", "sellScrap", "inquiry"].includes(key)).map(({ key, path }) => <li key={key}><Link href={`/${locale}${path}`}>{text[key]}</Link></li>)}</ul></nav>
        <div className="footer-contact"><h2>{text.contactTitle}</h2><address><p>{text.address}</p><p>{text.phone}</p><p>{text.email}</p></address><h3>{text.social}</h3><p className="social-note">{text.socialPending}</p><div className="social-placeholders" aria-label={text.social}><span aria-disabled="true">LinkedIn</span><span aria-disabled="true">Instagram</span></div></div>
      </div>
      <div className="container footer-bottom"><small>© {new Date().getFullYear()} {text.brand}. {text.rights}</small><span lang="en" dir="ltr">STEEL · SUPPLY · TRADE</span></div>
    </footer>
  );
}

